//DOM
var inp = document.getElementById("inp");
var btns = document.querySelectorAll(".btn");
var lin = btns[0];
var rin = btns[1];
var lout = btns[2];
var rout = btns[3];
var wrap = document.querySelector(".wrap");
var arr = [];

//通用的一些方法
function addEvent(element,event,listener) {
    if(element.addEventListener){
        element.addEventListener(event,listener);
    }
    else if(element.attachEvent){
        element.attachEvent("on"+event,listener);
    }
    else{
        element["on"+event] = listener;
    }
};
function getValue(){
    var val = inp.value.trim();
    if( !(/^\d+$/).test(val) ){
        throw new Error('请输入正整数');
        // alert("请输入正整数");
    }
    else{
        return parseInt(val);
    }
};

/*addEvent(lin,"click",function () {
    arr.unshift( getValue() );
    console.log(arr);
    // draw();
});*/
lin.addEventListener("click",function () {
    arr.unshift( getValue() );
    console.log(arr);
    // draw();
});

addEvent(rin,"click",function () {
    arr.push( getValue() );
    console.log(arr);
    draw();
});

addEvent(lout,"click",function () {
    alert(arr.shift());
    draw();
});

addEvent(rout,"click",function () {
    alert(arr.pop());
    draw();
});
/*function draw() {
    wrap.innerHTML="";
    var str = "";
    arr.map(function (item) {
        return str += "<li>"+item+"</li>";
    });
    wrap.innerHTML=str;
    console.log(1);
};*/

